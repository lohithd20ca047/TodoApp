import 'package:flutter/material.dart';

import 'view/todo_app.dart';

void main() {
  runApp(const TodoApp());
}

