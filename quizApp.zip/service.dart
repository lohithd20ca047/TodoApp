import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'model.dart';

List<Country> getAllCountries() {
  var filePath = 'D:\\New folder\\quizApp\\country.json';
  var fileObj = File(filePath);
  var countries = <Country>[];
  if (!fileObj.existsSync()) {
    return countries;
  }
  var contents = fileObj.readAsStringSync();
  var countriesJson = jsonDecode(contents);

  for (var countryJson in countriesJson) {
    var country = Country.fromJson(countryJson);
    countries.add(country);
  }
  return countries;
}

Country getRandomCountry(List<Country> countries) {
  var rng = Random();
  var index = rng.nextInt(countries.length);
  return countries[index];
}

void main(List<String> args) {
  var countries = getAllCountries();

  var four = <Country>[];
  for (var i = 0; i <= 3; i++) {
    var country = getRandomCountry(countries);
    print(country.name!.common);
  }
}
